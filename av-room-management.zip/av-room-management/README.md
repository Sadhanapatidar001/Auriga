# 🎬 AV Room Management System

A full-stack web application designed for managing college Audio-Visual (AV) rooms, equipment, bookings, and schedules.

---

## 🛠️ Tech Stack

- **Frontend**: React (v19), TypeScript, Vite, Tailwind CSS (v4)
- **Backend**: Node.js, Express, TypeScript
- **Database**: MySQL (Database name: `av_room_db`)
- **ORM**: Prisma
- **Authentication**: JWT (JSON Web Tokens) & bcryptjs *(to be configured in upcoming phase)*

---

## 📁 Project Structure

Frontend and backend are decoupled into separate folders for clarity and maintainability:

```text
av-room-management/
├── frontend/                     # React + TypeScript + Vite Client
│   ├── src/
│   │   ├── components/           # Reusable UI components
│   │   ├── pages/                # Application pages/views
│   │   ├── App.tsx               # Main UI component
│   │   ├── main.tsx              # React DOM entry point
│   │   └── index.css             # Tailwind CSS styles
│   ├── public/                   # Static assets
│   ├── .env.example              # Frontend environment variables template
│   ├── package.json              # Frontend dependencies and scripts
│   ├── tsconfig.json             # Frontend TypeScript configuration
│   └── vite.config.ts            # Vite configuration
│
├── backend/                      # Node.js + Express + TypeScript API Server
│   ├── src/
│   │   ├── config/               # Database & Prisma client singleton
│   │   │   └── db.ts
│   │   ├── controllers/          # API route controllers
│   │   ├── middlewares/          # Express middlewares (auth, errors, etc.)
│   │   ├── routes/               # API route handlers
│   │   │   ├── health.routes.ts  # Health check endpoint
│   │   │   └── index.ts          # Central API route index
│   │   └── server.ts             # Express server entry point
│   ├── prisma/
│   │   └── schema.prisma         # Prisma schema configured for MySQL
│   ├── .env.example              # Backend environment variables template
│   ├── package.json              # Backend dependencies and scripts
│   └── tsconfig.json             # Backend TypeScript configuration
│
└── README.md                     # Project documentation and setup guide
```

---

## 🚀 Quick Start Guide (Beginner Friendly)

### 1. Prerequisites
Make sure you have the following installed on your machine:
- **Node.js** (v18 or higher recommended) - [Download Node.js](https://nodejs.org/)
- **MySQL Server** (e.g. MySQL Community Server or XAMPP)

---

### 2. Backend Setup

1. Open a terminal and navigate to the backend folder:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure environment variables:
   - Copy `.env.example` to `.env`:
     ```bash
     cp .env.example .env
     ```
     *(On Windows PowerShell: `Copy-Item .env.example .env`)*
   - Open `.env` and verify your MySQL credentials:
     ```env
     PORT=5000
     NODE_ENV=development
     DATABASE_URL="mysql://root:your_mysql_password@localhost:3306/av_room_db"
     JWT_SECRET="your_secret_key"
     CLIENT_URL="http://localhost:5173"
     ```

4. Start the backend development server:
   ```bash
   npm run dev
   ```
   The backend API will run at **`http://localhost:5000`**.  
   You can verify it by opening **`http://localhost:5000/api/health`** in your browser.

---

### 3. Frontend Setup

1. Open a **new terminal window** and navigate to the frontend folder:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure environment variables:
   - Copy `.env.example` to `.env`:
     ```bash
     cp .env.example .env
     ```
     *(On Windows PowerShell: `Copy-Item .env.example .env`)*

4. Start the frontend development server:
   ```bash
   npm run dev
   ```
   The frontend will run at **`http://localhost:5173`**. Open this URL in your browser to view the application.

---

## 📜 Available Scripts

### Backend (`/backend`)
- `npm run dev` - Start development server with automatic reload (`ts-node-dev`)
- `npm run build` - Compile TypeScript to JavaScript in `/dist`
- `npm start` - Run the compiled production build
- `npm run prisma:generate` - Generate Prisma client

### Frontend (`/frontend`)
- `npm run dev` - Start the Vite development server
- `npm run build` - Type check and build production-ready assets in `/dist`
- `npm run preview` - Locally preview production build

---

## 📌 Next Phases
- Phase 2: Design and apply MySQL database schema using Prisma (Users, Rooms, Bookings, Equipment).
- Phase 3: Implement Authentication & Authorization (JWT, Roles: Admin, Faculty, Staff).
- Phase 4: Build Room Booking & Equipment Management API endpoints.
- Phase 5: Build Frontend User Interface (Dashboard, Booking Calendar, Admin Panel).
