import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'
import { Role } from '@prisma/client'

// Extend Express Request interface to include user
export interface AuthUserPayload {
  userId: number
  email: string
  role: Role
  name?: string
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUserPayload
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET || 'your_super_secret_jwt_key_replace_this_in_production'

/**
 * Middleware to verify JWT authentication token
 */
export const authenticateJWT = (req: Request, res: Response, next: NextFunction): void => {
  const authHeader = req.headers.authorization

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      status: 'error',
      message: 'Authentication token required. Please provide a valid Bearer token in the Authorization header.',
    })
    return
  }

  const token = authHeader.split(' ')[1]

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthUserPayload
    req.user = decoded
    next()
  } catch (error) {
    res.status(401).json({
      status: 'error',
      message: 'Invalid or expired authentication token',
    })
    return
  }
}

/**
 * Middleware to restrict route access to specific roles (e.g. ADMIN)
 */
export const requireRole = (roles: Role[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({
        status: 'error',
        message: 'Authentication required',
      })
      return
    }

    if (!roles.includes(req.user.role)) {
      res.status(403).json({
        status: 'error',
        message: `Forbidden: requires one of the following roles: [${roles.join(', ')}]. Current role: ${req.user.role}`,
      })
      return
    }

    next()
  }
}

/**
 * Convenient shortcut for requiring ADMIN authorization
 */
export const requireAdmin = requireRole([Role.ADMIN])
