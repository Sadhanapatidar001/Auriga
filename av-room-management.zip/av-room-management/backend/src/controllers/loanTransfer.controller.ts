import { Request, Response } from 'express'
import { prisma } from '../config/db'
import { LoanStatus, Role } from '@prisma/client'

// Configurable active loans limit per borrower
export const MAX_ACTIVE_LOANS_PER_USER = parseInt(process.env.MAX_ACTIVE_LOANS || '3', 10)

// In-Memory fallback store for seamless development/testing
export interface MemoryUser {
  id: number
  name: string
  email: string
  studentId?: string | null
  role: Role
}

export interface MemoryUnit {
  id: number
  assetCode: string
  serialNumber?: string | null
  status: string
}

export interface MemoryLoan {
  id: number
  borrowerId: number
  equipmentId: number
  quantity: number
  bookingDate: Date
  borrowDate: Date
  dueDate: Date
  actualReturnDate?: Date | null
  status: LoanStatus
  depositAmount: number
  lateFee: number
  refundAmount: number
  borrower: MemoryUser
  equipment: { id: number; name: string; category: string; totalQuantity: number }
  loanUnits: { equipmentUnit: MemoryUnit }[]
  deposit?: { id: number; borrowerId: number; depositAmount: number; status: string }
}

export interface MemoryTransfer {
  id: number
  loanId: number
  fromBorrowerId: number
  toBorrowerId: number
  transferredById: number
  transferredAt: Date
  reason?: string | null
  fromBorrower: { id: number; name: string; email: string }
  toBorrower: { id: number; name: string; email: string }
  transferredBy: { id: number; name: string; email: string }
}

export const memoryStore = {
  users: [
    { id: 1, name: 'AV Room Admin', email: 'admin@college.edu', studentId: null, role: Role.ADMIN },
    { id: 2, name: 'Student A (John Doe)', email: 'student.a@college.edu', studentId: 'STU-1001', role: Role.STUDENT },
    { id: 3, name: 'Student B (Jane Smith)', email: 'student.b@college.edu', studentId: 'STU-1002', role: Role.STUDENT },
    { id: 4, name: 'Student C (Alex Wong)', email: 'student.c@college.edu', studentId: 'STU-1003', role: Role.STUDENT },
  ] as MemoryUser[],

  loans: [
    {
      id: 1,
      borrowerId: 2,
      equipmentId: 1,
      quantity: 1,
      bookingDate: new Date('2026-09-14T09:00:00.000Z'),
      borrowDate: new Date('2026-09-15T10:00:00.000Z'),
      dueDate: new Date('2026-09-25T17:00:00.000Z'),
      actualReturnDate: null,
      status: LoanStatus.ACTIVE,
      depositAmount: 50.0,
      lateFee: 0.0,
      refundAmount: 0.0,
      borrower: { id: 2, name: 'Student A (John Doe)', email: 'student.a@college.edu', studentId: 'STU-1001', role: Role.STUDENT },
      equipment: { id: 1, name: 'Sony A7 IV 4K Camera Kit', category: 'Camera', totalQuantity: 3 },
      loanUnits: [{ equipmentUnit: { id: 101, assetCode: 'CAM-SONY-01', serialNumber: 'SN-98234', status: 'BORROWED' } }],
      deposit: { id: 1, borrowerId: 2, depositAmount: 50.0, status: 'HELD' },
    },
    {
      id: 2,
      borrowerId: 4,
      equipmentId: 2,
      quantity: 1,
      bookingDate: new Date('2026-09-12T14:00:00.000Z'),
      borrowDate: new Date('2026-09-14T11:00:00.000Z'),
      dueDate: new Date('2026-09-22T16:00:00.000Z'),
      actualReturnDate: null,
      status: LoanStatus.ACTIVE,
      depositAmount: 100.0,
      lateFee: 0.0,
      refundAmount: 0.0,
      borrower: { id: 4, name: 'Student C (Alex Wong)', email: 'student.c@college.edu', studentId: 'STU-1003', role: Role.STUDENT },
      equipment: { id: 2, name: 'Epson Pro EX11000 Laser Projector', category: 'Projector', totalQuantity: 5 },
      loanUnits: [{ equipmentUnit: { id: 201, assetCode: 'PRJ-EPS-01', serialNumber: 'SN-44123', status: 'BORROWED' } }],
      deposit: { id: 2, borrowerId: 4, depositAmount: 100.0, status: 'HELD' },
    },
    {
      id: 3,
      borrowerId: 3,
      equipmentId: 3,
      quantity: 1,
      bookingDate: new Date('2026-09-01T08:00:00.000Z'),
      borrowDate: new Date('2026-09-02T10:00:00.000Z'),
      dueDate: new Date('2026-09-08T17:00:00.000Z'),
      actualReturnDate: new Date('2026-09-08T15:30:00.000Z'),
      status: LoanStatus.RETURNED,
      depositAmount: 25.0,
      lateFee: 0.0,
      refundAmount: 25.0,
      borrower: { id: 3, name: 'Student B (Jane Smith)', email: 'student.b@college.edu', studentId: 'STU-1002', role: Role.STUDENT },
      equipment: { id: 3, name: 'Shure Wireless Lavalier Mic System', category: 'Audio', totalQuantity: 4 },
      loanUnits: [{ equipmentUnit: { id: 301, assetCode: 'MIC-SHU-01', serialNumber: 'SN-11002', status: 'AVAILABLE' } }],
      deposit: { id: 3, borrowerId: 3, depositAmount: 25.0, status: 'REFUNDED' },
    },
  ] as MemoryLoan[],

  transfers: [] as MemoryTransfer[],
}

/**
 * Controller to handle transferring an active loan to a new borrower.
 */
export const transferLoan = async (req: Request, res: Response): Promise<void> => {
  try {
    const loanId = parseInt(req.params.loanId, 10)
    if (isNaN(loanId)) {
      res.status(400).json({ status: 'error', message: 'Invalid loan ID provided' })
      return
    }

    const { newBorrowerId, reason } = req.body
    const targetBorrowerId = parseInt(newBorrowerId, 10)
    if (isNaN(targetBorrowerId)) {
      res.status(400).json({ status: 'error', message: 'A valid numeric newBorrowerId is required' })
      return
    }

    const transferredById = req.user?.userId || 1

    // 1. Try finding in DB first
    let dbLoan = null
    try {
      dbLoan = await prisma.loan.findUnique({
        where: { id: loanId },
        include: {
          borrower: { select: { id: true, name: true, email: true, studentId: true } },
          equipment: { select: { id: true, name: true, category: true } },
          loanUnits: {
            include: {
              equipmentUnit: { select: { id: true, assetCode: true, serialNumber: true, status: true } },
            },
          },
          deposit: true,
        },
      })
    } catch (e) {
      dbLoan = null
    }

    // 2. If found in DB, perform Prisma Transaction
    if (dbLoan) {
      const result = await prisma.$transaction(async (tx) => {
        if (dbLoan.status !== LoanStatus.ACTIVE) {
          throw {
            statusCode: 400,
            message: `Only ACTIVE loans can be transferred. Current loan status is '${dbLoan.status}'. Non-active loans cannot be transferred.`,
          }
        }

        const targetBorrower = await tx.user.findUnique({
          where: { id: targetBorrowerId },
          select: { id: true, name: true, email: true, studentId: true, role: true },
        })

        if (!targetBorrower) {
          throw { statusCode: 404, message: `Target borrower with ID ${targetBorrowerId} does not exist in the system` }
        }

        if (dbLoan.borrowerId === targetBorrowerId) {
          throw {
            statusCode: 400,
            message: `Target borrower is already the current borrower of this loan. Transfer must be to a different user.`,
          }
        }

        const activeLoanCount = await tx.loan.count({
          where: { borrowerId: targetBorrowerId, status: LoanStatus.ACTIVE },
        })

        if (activeLoanCount >= MAX_ACTIVE_LOANS_PER_USER) {
          throw {
            statusCode: 400,
            message: `Transfer rejected: Target borrower (${targetBorrower.name}) has reached the maximum allowed active loans limit (${MAX_ACTIVE_LOANS_PER_USER} active loans).`,
          }
        }

        const updatedLoan = await tx.loan.update({
          where: { id: loanId },
          data: {
            borrowerId: targetBorrowerId,
            dueDate: dbLoan.dueDate,
            borrowDate: dbLoan.borrowDate,
            bookingDate: dbLoan.bookingDate,
            status: LoanStatus.ACTIVE,
          },
          include: {
            borrower: { select: { id: true, name: true, email: true, studentId: true } },
          },
        })

        if (dbLoan.deposit) {
          await tx.deposit.update({
            where: { loanId: dbLoan.id },
            data: { borrowerId: targetBorrowerId },
          })
        }

        const transferRecord = await tx.loanTransfer.create({
          data: {
            loanId: dbLoan.id,
            fromBorrowerId: dbLoan.borrowerId,
            toBorrowerId: targetBorrowerId,
            transferredById,
            transferredAt: new Date(),
            reason: reason ? String(reason).trim() : null,
          },
        })

        return {
          loanId: updatedLoan.id,
          previousBorrower: dbLoan.borrower,
          newBorrower: updatedLoan.borrower,
          equipment: dbLoan.equipment,
          assignedUnits: dbLoan.loanUnits.map((lu) => lu.equipmentUnit),
          quantity: updatedLoan.quantity,
          borrowDate: updatedLoan.borrowDate,
          originalDueDate: updatedLoan.dueDate,
          currentStatus: updatedLoan.status,
          transferredAt: transferRecord.transferredAt,
          transferId: transferRecord.id,
          reason: transferRecord.reason,
        }
      })

      res.status(200).json({
        status: 'success',
        message: 'Active loan successfully transferred to new borrower. Original due date and equipment availability remain unchanged.',
        data: result,
      })
      return
    }

    // 3. Fallback: Memory Store Transfer Transaction
    const loan = memoryStore.loans.find((l) => l.id === loanId)
    if (!loan) {
      res.status(404).json({ status: 'error', message: `Loan with ID ${loanId} not found` })
      return
    }

    if (loan.status !== LoanStatus.ACTIVE) {
      res.status(400).json({
        status: 'error',
        message: `Only ACTIVE loans can be transferred. Current loan status is '${loan.status}'. Non-active loans cannot be transferred.`,
      })
      return
    }

    const targetBorrower = memoryStore.users.find((u) => u.id === targetBorrowerId)
    if (!targetBorrower) {
      res.status(404).json({
        status: 'error',
        message: `Target borrower with ID ${targetBorrowerId} does not exist in the system`,
      })
      return
    }

    if (loan.borrowerId === targetBorrowerId) {
      res.status(400).json({
        status: 'error',
        message: 'Target borrower is already the current borrower of this loan. Transfer must be to a different user.',
      })
      return
    }

    const activeCount = memoryStore.loans.filter(
      (l) => l.borrowerId === targetBorrowerId && l.status === LoanStatus.ACTIVE
    ).length

    if (activeCount >= MAX_ACTIVE_LOANS_PER_USER) {
      res.status(400).json({
        status: 'error',
        message: `Transfer rejected: Target borrower (${targetBorrower.name}) has reached the maximum allowed active loans limit (${MAX_ACTIVE_LOANS_PER_USER} active loans).`,
      })
      return
    }

    const previousBorrower = { ...loan.borrower }
    const transferTimestamp = new Date()

    // Update in-memory loan
    loan.borrowerId = targetBorrowerId
    loan.borrower = { ...targetBorrower }

    // Log in memory transfers
    const newTransferId = memoryStore.transfers.length + 1
    const adminUser = memoryStore.users.find((u) => u.id === transferredById) || memoryStore.users[0]
    const transferRecord: MemoryTransfer = {
      id: newTransferId,
      loanId: loan.id,
      fromBorrowerId: previousBorrower.id,
      toBorrowerId: targetBorrower.id,
      transferredById,
      transferredAt: transferTimestamp,
      reason: reason ? String(reason).trim() : null,
      fromBorrower: { id: previousBorrower.id, name: previousBorrower.name, email: previousBorrower.email },
      toBorrower: { id: targetBorrower.id, name: targetBorrower.name, email: targetBorrower.email },
      transferredBy: { id: adminUser.id, name: adminUser.name, email: adminUser.email },
    }
    memoryStore.transfers.unshift(transferRecord)

    res.status(200).json({
      status: 'success',
      message: 'Active loan successfully transferred to new borrower. Original due date and equipment availability remain unchanged.',
      data: {
        loanId: loan.id,
        previousBorrower,
        newBorrower: loan.borrower,
        equipment: loan.equipment,
        assignedUnits: loan.loanUnits.map((lu) => lu.equipmentUnit),
        quantity: loan.quantity,
        borrowDate: loan.borrowDate,
        originalDueDate: loan.dueDate,
        currentStatus: loan.status,
        transferredAt: transferTimestamp,
        transferId: newTransferId,
        reason: transferRecord.reason,
      },
    })
  } catch (error: any) {
    if (error.statusCode) {
      res.status(error.statusCode).json({ status: 'error', message: error.message })
      return
    }
    console.error('Loan transfer error:', error)
    res.status(500).json({
      status: 'error',
      message: 'Failed to transfer loan due to an internal server error',
      error: error.message,
    })
  }
}
