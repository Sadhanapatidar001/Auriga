import { Request, Response } from 'express'
import { prisma } from '../config/db'
import { LoanStatus } from '@prisma/client'
import { memoryStore } from './loanTransfer.controller'

/**
 * Get all loans with relations for the dashboard
 */
export const getLoans = async (_req: Request, res: Response): Promise<void> => {
  try {
    let loans: any[] = []
    try {
      loans = await prisma.loan.findMany({
        orderBy: { id: 'desc' },
        include: {
          borrower: {
            select: { id: true, name: true, email: true, studentId: true, role: true },
          },
          equipment: {
            select: { id: true, name: true, category: true, totalQuantity: true },
          },
          loanUnits: {
            include: {
              equipmentUnit: {
                select: { id: true, assetCode: true, serialNumber: true, condition: true, status: true },
              },
            },
          },
          deposit: true,
          transfers: {
            orderBy: { transferredAt: 'desc' },
            include: {
              fromBorrower: { select: { id: true, name: true, email: true } },
              toBorrower: { select: { id: true, name: true, email: true } },
              transferredBy: { select: { id: true, name: true, email: true } },
            },
          },
        },
      })
    } catch (dbError) {
      loans = []
    }

    // If DB returned 0 records, supply development mock data
    if (!loans || loans.length === 0) {
      const loansWithTransfers = memoryStore.loans.map((loan) => ({
        ...loan,
        transfers: memoryStore.transfers.filter((t) => t.loanId === loan.id),
      }))

      res.status(200).json({
        status: 'success',
        count: loansWithTransfers.length,
        data: loansWithTransfers,
      })
      return
    }

    res.status(200).json({
      status: 'success',
      count: loans.length,
      data: loans,
    })
  } catch (error: any) {
    console.error('Error fetching loans:', error)
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch loans',
      error: error.message,
    })
  }
}

/**
 * Get a single loan by ID
 */
export const getLoanById = async (req: Request, res: Response): Promise<void> => {
  try {
    const loanId = parseInt(req.params.id, 10)
    if (isNaN(loanId)) {
      res.status(400).json({ status: 'error', message: 'Invalid loan ID' })
      return
    }

    let loan: any = null
    try {
      loan = await prisma.loan.findUnique({
        where: { id: loanId },
        include: {
          borrower: {
            select: { id: true, name: true, email: true, studentId: true, role: true },
          },
          equipment: true,
          loanUnits: {
            include: {
              equipmentUnit: true,
            },
          },
          deposit: true,
          transfers: {
            orderBy: { transferredAt: 'desc' },
            include: {
              fromBorrower: { select: { id: true, name: true, email: true } },
              toBorrower: { select: { id: true, name: true, email: true } },
              transferredBy: { select: { id: true, name: true, email: true } },
            },
          },
        },
      })
    } catch (e) {
      loan = null
    }

    if (!loan) {
      const memLoan = memoryStore.loans.find((l) => l.id === loanId)
      if (!memLoan) {
        res.status(404).json({ status: 'error', message: 'Loan not found' })
        return
      }

      const transfers = memoryStore.transfers.filter((t) => t.loanId === loanId)
      res.status(200).json({ status: 'success', data: { ...memLoan, transfers } })
      return
    }

    res.status(200).json({ status: 'success', data: loan })
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: 'Failed to retrieve loan', error: error.message })
  }
}

/**
 * Get equipment availability stats to demonstrate availability is unaffected by transfers
 */
export const getAvailabilityStats = async (_req: Request, res: Response): Promise<void> => {
  try {
    let stats: any[] = []
    try {
      const equipmentList = await prisma.equipment.findMany({
        include: {
          units: true,
          loans: {
            where: { status: LoanStatus.ACTIVE },
          },
        },
      })

      if (equipmentList && equipmentList.length > 0) {
        stats = equipmentList.map((eq) => {
          const activeLoanedCount = eq.loans.reduce((acc, curr) => acc + curr.quantity, 0)
          const availableQuantity = Math.max(0, eq.totalQuantity - activeLoanedCount)

          return {
            equipmentId: eq.id,
            name: eq.name,
            category: eq.category,
            totalQuantity: eq.totalQuantity,
            activeLoanedQuantity: activeLoanedCount,
            availableQuantity,
          }
        })
      }
    } catch (e) {
      stats = []
    }

    if (!stats || stats.length === 0) {
      const equipmentMap = new Map<number, { id: number; name: string; category: string; totalQuantity: number }>()
      for (const l of memoryStore.loans) {
        if (!equipmentMap.has(l.equipment.id)) {
          equipmentMap.set(l.equipment.id, l.equipment)
        }
      }

      stats = Array.from(equipmentMap.values()).map((eq) => {
        const activeLoanedCount = memoryStore.loans
          .filter((l) => l.equipmentId === eq.id && l.status === LoanStatus.ACTIVE)
          .reduce((acc, curr) => acc + curr.quantity, 0)
        const availableQuantity = Math.max(0, eq.totalQuantity - activeLoanedCount)

        return {
          equipmentId: eq.id,
          name: eq.name,
          category: eq.category,
          totalQuantity: eq.totalQuantity,
          activeLoanedQuantity: activeLoanedCount,
          availableQuantity,
        }
      })
    }

    res.status(200).json({
      status: 'success',
      data: stats,
    })
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: 'Failed to fetch stats', error: error.message })
  }
}
