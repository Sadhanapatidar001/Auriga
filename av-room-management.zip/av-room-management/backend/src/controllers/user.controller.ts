import { Request, Response } from 'express'
import { prisma } from '../config/db'
import jwt from 'jsonwebtoken'
import { Role } from '@prisma/client'
import { memoryStore } from './loanTransfer.controller'

const JWT_SECRET = process.env.JWT_SECRET || 'your_super_secret_jwt_key_replace_this_in_production'

/**
 * Get all users for borrower search/selection
 */
export const getUsers = async (_req: Request, res: Response): Promise<void> => {
  try {
    let users: any[] = []
    try {
      users = await prisma.user.findMany({
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          studentId: true,
          clubName: true,
          createdAt: true,
        },
        orderBy: { name: 'asc' },
      })
    } catch (e) {
      users = []
    }

    if (!users || users.length === 0) {
      users = memoryStore.users
    }

    res.status(200).json({
      status: 'success',
      count: users.length,
      data: users,
    })
  } catch (error: any) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch users',
      error: error.message,
    })
  }
}

/**
 * Issue a development JWT token for testing/demo purposes
 */
export const generateDevToken = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId = 1, role = Role.ADMIN, email = 'admin@college.edu' } = req.body

    const token = jwt.sign(
      {
        userId: Number(userId),
        email,
        role,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    )

    res.status(200).json({
      status: 'success',
      token,
      user: {
        userId: Number(userId),
        email,
        role,
      },
    })
  } catch (error: any) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to generate token',
      error: error.message,
    })
  }
}
