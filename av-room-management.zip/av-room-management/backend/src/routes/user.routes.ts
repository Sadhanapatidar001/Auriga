import { Router } from 'express'
import { getUsers, generateDevToken } from '../controllers/user.controller'

const router = Router()

// Route to get list of users (e.g. for borrower dropdown)
router.get('/', getUsers)

// Route to issue JWT token for testing/demo
router.post('/token', generateDevToken)

export default router
