import { Router } from 'express'
import healthRoutes from './health.routes'
import loanRoutes from './loan.routes'
import userRoutes from './user.routes'

const apiRouter = Router()

// Register modular routes
apiRouter.use('/', healthRoutes)
apiRouter.use('/loans', loanRoutes)
apiRouter.use('/users', userRoutes)
apiRouter.use('/auth', userRoutes)

export default apiRouter

