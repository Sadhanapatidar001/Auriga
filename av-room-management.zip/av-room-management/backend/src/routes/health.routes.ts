import { Router, Request, Response } from 'express'

const router = Router()

/**
 * @route   GET /api/health
 * @desc    Check backend service health and status
 * @access  Public
 */
router.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'success',
    message: 'AV Room Management API is running smoothly',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
  })
})

export default router
