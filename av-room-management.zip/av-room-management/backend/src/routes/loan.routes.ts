import { Router } from 'express'
import { transferLoan } from '../controllers/loanTransfer.controller'
import { getLoans, getLoanById, getAvailabilityStats } from '../controllers/loan.controller'
import { authenticateJWT, requireAdmin } from '../middlewares/auth'

const router = Router()

// Public read endpoints for dashboard
router.get('/', getLoans)
router.get('/stats/availability', getAvailabilityStats)
router.get('/:id', getLoanById)

/**
 * @route   POST /api/loans/:loanId/transfer
 * @desc    Transfer an active loan to a new borrower (Unchanged due date & unaffected availability)
 * @access  Protected (Requires JWT Authentication & ADMIN Role)
 */
router.post('/:loanId/transfer', authenticateJWT, requireAdmin, transferLoan)

export default router
