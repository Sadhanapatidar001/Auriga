import express, { Request, Response, NextFunction } from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import apiRoutes from './routes'

// Load environment variables
dotenv.config()

const app = express()
const PORT = process.env.PORT || 5000
const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:5173'

// Middlewares
app.use(
  cors({
    origin: CLIENT_URL,
    credentials: true,
  })
)
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Root Route
app.get('/', (_req: Request, res: Response) => {
  res.status(200).json({
    name: 'AV Room Management API',
    version: '1.0.0',
    status: 'online',
    healthCheck: '/api/health',
  })
})

// Mount API Routes
app.use('/api', apiRoutes)

// 404 Route Not Found Handler
app.use((_req: Request, res: Response) => {
  res.status(404).json({
    status: 'error',
    message: 'Endpoint not found',
  })
})

// Global Error Handler
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Unhandled server error:', err)
  res.status(500).json({
    status: 'error',
    message: 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { error: err.message }),
  })
})

// Start listening
const server = app.listen(PORT, () => {
  console.log(`=========================================`)
  console.log(`🚀 AV Room Management Server is running`)
  console.log(`📡 URL: http://localhost:${PORT}`)
  console.log(`🩺 Health: http://localhost:${PORT}/api/health`)
  console.log(`⚙️  Environment: ${process.env.NODE_ENV || 'development'}`)
  console.log(`=========================================`)
})

// Graceful Shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server')
  server.close(() => {
    console.log('HTTP server closed')
  })
})

export default app
