-- CreateTable
CREATE TABLE `LoanTransfer` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `loanId` INTEGER NOT NULL,
    `fromBorrowerId` INTEGER NOT NULL,
    `toBorrowerId` INTEGER NOT NULL,
    `transferredById` INTEGER NOT NULL,
    `transferredAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `reason` TEXT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `LoanTransfer_loanId_idx`(`loanId`),
    INDEX `LoanTransfer_fromBorrowerId_idx`(`fromBorrowerId`),
    INDEX `LoanTransfer_toBorrowerId_idx`(`toBorrowerId`),
    INDEX `LoanTransfer_transferredById_idx`(`transferredById`),
    INDEX `LoanTransfer_transferredAt_idx`(`transferredAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `LoanTransfer` ADD CONSTRAINT `LoanTransfer_loanId_fkey` FOREIGN KEY (`loanId`) REFERENCES `Loan`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `LoanTransfer` ADD CONSTRAINT `LoanTransfer_fromBorrowerId_fkey` FOREIGN KEY (`fromBorrowerId`) REFERENCES `User`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `LoanTransfer` ADD CONSTRAINT `LoanTransfer_toBorrowerId_fkey` FOREIGN KEY (`toBorrowerId`) REFERENCES `User`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `LoanTransfer` ADD CONSTRAINT `LoanTransfer_transferredById_fkey` FOREIGN KEY (`transferredById`) REFERENCES `User`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
