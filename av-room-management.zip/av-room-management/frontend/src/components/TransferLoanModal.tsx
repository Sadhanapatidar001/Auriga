import React, { useState } from 'react'

export interface Borrower {
  id: number
  name: string
  email: string
  studentId?: string | null
  role?: string
}

export interface EquipmentUnit {
  id: number
  assetCode: string
  serialNumber?: string | null
  status?: string
}

export interface Loan {
  id: number
  borrowerId: number
  equipmentId: number
  quantity: number
  borrowDate: string
  dueDate: string
  bookingDate?: string
  status: 'ACTIVE' | 'RETURNED' | 'REQUESTED' | 'APPROVED' | 'REJECTED' | 'OVERDUE' | 'CANCELLED'
  borrower: Borrower
  equipment: {
    id: number
    name: string
    category: string
    totalQuantity?: number
  }
  loanUnits?: { equipmentUnit: EquipmentUnit }[]
  transfers?: {
    id: number
    transferredAt: string
    reason?: string | null
    fromBorrower: { name: string }
    toBorrower: { name: string }
    transferredBy: { name: string }
  }[]
}

interface TransferLoanModalProps {
  loan: Loan | null
  isOpen: boolean
  users: Borrower[]
  onClose: () => void
  onSuccess: (message: string) => void
}

export const TransferLoanModal: React.FC<TransferLoanModalProps> = ({
  loan,
  isOpen,
  users,
  onClose,
  onSuccess,
}) => {
  const [selectedBorrowerId, setSelectedBorrowerId] = useState<number | ''>('')
  const [reason, setReason] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [confirmed, setConfirmed] = useState(false)

  if (!isOpen || !loan) return null

  // Eligible target borrowers (exclude current borrower)
  const availableBorrowers = users.filter((u) => u.id !== loan.borrowerId)
  const selectedBorrower = availableBorrowers.find((u) => u.id === Number(selectedBorrowerId))

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr)
      return d.toLocaleDateString('en-US', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    } catch {
      return dateStr
    }
  }

  const handleTransfer = async () => {
    if (!selectedBorrowerId) {
      setError('Please select a valid target borrower.')
      return
    }

    if (!confirmed) {
      setConfirmed(true)
      return
    }

    setLoading(true)
    setError(null)

    try {
      // Obtain Admin JWT token from backend auth endpoint
      const tokenRes = await fetch('http://localhost:5000/api/auth/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: 1, role: 'ADMIN', email: 'admin@college.edu' }),
      })
      const tokenData = await tokenRes.json()
      const token = tokenData.token

      // Execute transfer
      const response = await fetch(`http://localhost:5000/api/loans/${loan.id}/transfer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          newBorrowerId: Number(selectedBorrowerId),
          reason: reason.trim() || undefined,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || 'Failed to transfer loan')
      }

      onSuccess(
        `Successfully transferred Loan #${loan.id} to ${data.data.newBorrower.name}! Original due date (${formatDate(
          data.data.originalDueDate
        )}) and equipment availability remain strictly unchanged.`
      )
      onClose()
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during loan transfer')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-sm">
              ⇄
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Transfer Active Loan #{loan.id}</h3>
              <p className="text-xs text-slate-500">{loan.equipment.name} ({loan.equipment.category})</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-lg p-1 rounded-md transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          {error && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start space-x-2">
              <span className="font-bold">⚠️</span>
              <span>{error}</span>
            </div>
          )}

          {/* Current Details Card */}
          <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider block">
                Current Borrower
              </span>
              <p className="text-slate-900 font-semibold mt-0.5">{loan.borrower.name}</p>
              <p className="text-slate-500 text-[11px]">{loan.borrower.email}</p>
            </div>
            <div>
              <span className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider block">
                Original Due Date
              </span>
              <p className="text-indigo-700 font-bold mt-0.5">{formatDate(loan.dueDate)}</p>
              <p className="text-emerald-600 font-medium text-[11px]">Carries over unchanged</p>
            </div>
          </div>

          {/* Unit & Quantity Info */}
          <div className="flex items-center justify-between px-3 py-2 bg-indigo-50/60 rounded-lg text-xs text-indigo-900 border border-indigo-100">
            <span>
              <strong>Physical Units:</strong>{' '}
              {loan.loanUnits && loan.loanUnits.length > 0
                ? loan.loanUnits.map((u) => u.equipmentUnit.assetCode).join(', ')
                : `Quantity: ${loan.quantity}`}
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-semibold">
              Status: {loan.status}
            </span>
          </div>

          {/* Target Borrower Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Select New Borrower <span className="text-rose-500">*</span>
            </label>
            <select
              value={selectedBorrowerId}
              onChange={(e) => {
                setSelectedBorrowerId(e.target.value ? Number(e.target.value) : '')
                setConfirmed(false)
                setError(null)
              }}
              className="w-full text-sm px-3 py-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">-- Choose target student / borrower --</option>
              {availableBorrowers.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name} ({user.studentId || user.email}) [{user.role}]
                </option>
              ))}
            </select>
          </div>

          {/* Transfer Reason */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Transfer Reason <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              placeholder="e.g. Lab project handover, scheduling shift"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full text-sm px-3 py-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          {/* Required Confirmation Summary & Warning Box */}
          {selectedBorrower && (
            <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs space-y-2.5">
              <div className="font-semibold text-amber-900 border-b border-amber-200/80 pb-1.5 flex items-center justify-between">
                <span>Confirmation Summary</span>
                <span className="text-[10px] uppercase font-bold text-amber-800 tracking-wider">
                  Review Details
                </span>
              </div>
              <div className="space-y-1 text-slate-700">
                <p>
                  <strong>Current borrower:</strong> {loan.borrower.name}
                </p>
                <p>
                  <strong>New borrower:</strong> {selectedBorrower.name} ({selectedBorrower.email})
                </p>
                <p>
                  <strong>Due date:</strong>{' '}
                  <span className="text-indigo-700 font-bold">{formatDate(loan.dueDate)}</span>
                </p>
              </div>

              {/* Exact Warning Required by Prompt */}
              <div className="p-2.5 bg-amber-100/90 rounded-lg text-amber-950 font-medium text-[11.5px] border border-amber-300 flex items-start space-x-2">
                <span className="text-sm">⚠️</span>
                <span>
                  <strong>Warning:</strong> &quot;The original due date will remain unchanged and equipment availability will not change.&quot;
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleTransfer}
            disabled={loading || !selectedBorrowerId}
            className={`px-5 py-2 text-xs font-semibold text-white rounded-lg shadow-sm transition-all cursor-pointer flex items-center space-x-1.5 ${
              confirmed
                ? 'bg-emerald-600 hover:bg-emerald-700 ring-2 ring-emerald-400'
                : 'bg-indigo-600 hover:bg-indigo-700'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {loading ? (
              <span>Processing...</span>
            ) : confirmed ? (
              <span>Confirm & Transfer Now ✓</span>
            ) : (
              <span>Review & Transfer Loan ➔</span>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
