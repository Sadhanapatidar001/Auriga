import { useState, useEffect } from 'react'
import { TransferLoanModal, type Loan, type Borrower } from './components/TransferLoanModal'


interface AvailabilityStat {
  equipmentId: number
  name: string
  category: string
  totalQuantity: number
  activeLoanedQuantity: number
  availableQuantity: number
}

function App() {
  const [loans, setLoans] = useState<Loan[]>([])
  const [users, setUsers] = useState<Borrower[]>([])
  const [availabilityStats, setAvailabilityStats] = useState<AvailabilityStat[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [selectedLoan, setSelectedLoan] = useState<Loan | null>(null)
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [viewingAuditLoan, setViewingAuditLoan] = useState<Loan | null>(null)

  const API_BASE = 'http://localhost:5000/api'

  const fetchData = async () => {
    setLoading(true)
    try {
      const [loansRes, usersRes, statsRes] = await Promise.all([
        fetch(`${API_BASE}/loans`),
        fetch(`${API_BASE}/users`),
        fetch(`${API_BASE}/loans/stats/availability`),
      ])

      const loansData = await loansRes.json()
      const usersData = await usersRes.json()
      const statsData = await statsRes.json()

      if (loansData.status === 'success') setLoans(loansData.data)
      if (usersData.status === 'success') setUsers(usersData.data)
      if (statsData.status === 'success') setAvailabilityStats(statsData.data)
    } catch (err: any) {
      console.error('Error fetching data:', err)
      setErrorMessage('Failed to connect to backend API server. Make sure the backend is running on port 5000.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  const handleOpenTransfer = (loan: Loan) => {
    setSelectedLoan(loan)
    setIsModalOpen(true)
  }

  const handleTransferSuccess = (msg: string) => {
    setSuccessMessage(msg)
    fetchData()
    setTimeout(() => setSuccessMessage(null), 9000)
  }

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr)
      return d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    } catch {
      return dateStr
    }
  }

  const activeLoans = loans.filter((l) => l.status === 'ACTIVE')

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Top Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-xl shadow-xs">
              AV
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 leading-tight">
                AV Room Management System
              </h1>
              <p className="text-xs text-slate-500">College AV Booking & Equipment Portal</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
              ● Phase 2 & The Twist Active
            </span>
            <button
              onClick={fetchData}
              className="px-3 py-1.5 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              ↻ Refresh Data
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full space-y-8">
        {/* Success Alert Banner */}
        {successMessage && (
          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-900 shadow-sm flex items-start justify-between animate-in fade-in duration-300">
            <div className="flex items-start space-x-3">
              <span className="text-xl">✅</span>
              <div>
                <h4 className="text-sm font-bold">Loan Transfer Successful!</h4>
                <p className="text-xs text-emerald-800 mt-0.5">{successMessage}</p>
              </div>
            </div>
            <button
              onClick={() => setSuccessMessage(null)}
              className="text-emerald-600 hover:text-emerald-900 text-sm font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* Error Alert Banner */}
        {errorMessage && (
          <div className="p-4 bg-rose-50 border border-rose-300 rounded-xl text-rose-900 shadow-sm flex items-start justify-between">
            <div className="flex items-start space-x-3">
              <span className="text-xl">⚠️</span>
              <div>
                <h4 className="text-sm font-bold">Notice</h4>
                <p className="text-xs text-rose-800 mt-0.5">{errorMessage}</p>
              </div>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-rose-600 hover:text-rose-900 text-sm font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* The Twist Feature Callout Banner */}
        <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
          <div className="relative z-10 max-w-3xl">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-indigo-500/30 border border-indigo-400/40 text-xs font-semibold tracking-wide text-indigo-200 mb-3">
              <span>★</span>
              <span>The Twist Requirement Implemented</span>
            </div>
            <h2 className="text-2xl font-black tracking-tight text-white mb-2">
              Active Loan Transfer System
            </h2>
            <p className="text-sm text-indigo-100 leading-relaxed">
              &quot;An active loan can be transferred from one borrower to another. The original due date carries over unchanged, and the item&apos;s availability is unaffected by the transfer.&quot;
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-indigo-200">
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>Original Due Date Strictly Maintained</span>
              </span>
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>Zero Equipment Availability Shift</span>
              </span>
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>Full Audit Trail in LoanTransfer</span>
              </span>
            </div>
          </div>
        </div>

        {/* Real-time Equipment Availability Grid */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">Equipment Catalog & Availability Tracking</h3>
              <p className="text-xs text-slate-500">
                Notice that transferring a loan does NOT affect available equipment quantities.
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md">
              Real-time Stock
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {availabilityStats.map((item) => (
              <div
                key={item.equipmentId}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:border-indigo-200 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    {item.category}
                  </span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {item.availableQuantity} Available
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mb-3">{item.name}</h4>
                <div className="grid grid-cols-3 gap-2 text-center text-xs pt-2 border-t border-slate-200">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Total</span>
                    <span className="font-bold text-slate-800">{item.totalQuantity}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">On Loan</span>
                    <span className="font-bold text-indigo-600">{item.activeLoanedQuantity}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">In Stock</span>
                    <span className="font-bold text-emerald-600">{item.availableQuantity}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Loans Management Section */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
            <div>
              <h3 className="text-base font-bold text-slate-900">Equipment Loans & Transfers</h3>
              <p className="text-xs text-slate-500">
                Manage active loans and perform authorized transfers between student borrowers.
              </p>
            </div>
            <div className="text-xs text-slate-600">
              Active Loans: <strong className="text-indigo-600">{activeLoans.length}</strong> / Total:{' '}
              {loans.length}
            </div>
          </div>

          {loading ? (
            <div className="p-12 text-center text-sm text-slate-500">Loading loan records...</div>
          ) : loans.length === 0 ? (
            <div className="p-12 text-center text-sm text-slate-500">No loan records found.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3.5">Loan ID</th>
                    <th className="px-6 py-3.5">Equipment & Units</th>
                    <th className="px-6 py-3.5">Current Borrower</th>
                    <th className="px-6 py-3.5">Original Due Date</th>
                    <th className="px-6 py-3.5">Status</th>
                    <th className="px-6 py-3.5">Transfers</th>
                    <th className="px-6 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {loans.map((loan) => {
                    const isActive = loan.status === 'ACTIVE'
                    const transferCount = loan.transfers ? loan.transfers.length : 0

                    return (
                      <tr key={loan.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="px-6 py-4 font-bold text-slate-900">#{loan.id}</td>
                        <td className="px-6 py-4">
                          <p className="font-semibold text-slate-900">{loan.equipment.name}</p>
                          <div className="flex items-center space-x-1 mt-1">
                            <span className="text-xs text-slate-500">Qty: {loan.quantity}</span>
                            {loan.loanUnits && loan.loanUnits.length > 0 && (
                              <span className="text-xs px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
                                {loan.loanUnits.map((lu) => lu.equipmentUnit.assetCode).join(', ')}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-semibold text-slate-900">{loan.borrower.name}</p>
                          <p className="text-xs text-slate-500">{loan.borrower.email}</p>
                          {loan.borrower.studentId && (
                            <span className="text-[10px] text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded font-mono font-medium">
                              {loan.borrower.studentId}
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-semibold text-indigo-900 text-xs">
                            {formatDate(loan.dueDate)}
                          </span>
                          <span className="block text-[11px] text-slate-400">
                            Borrowed: {formatDate(loan.borrowDate)}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                              loan.status === 'ACTIVE'
                                ? 'bg-emerald-100 text-emerald-800'
                                : loan.status === 'RETURNED'
                                ? 'bg-slate-100 text-slate-700'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {loan.status}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          {transferCount > 0 ? (
                            <button
                              onClick={() => setViewingAuditLoan(loan)}
                              className="inline-flex items-center space-x-1 px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-md text-xs font-semibold transition-colors cursor-pointer"
                            >
                              <span>⇄ Transferred {transferCount}x</span>
                            </button>
                          ) : (
                            <span className="text-xs text-slate-400">Original</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-right">
                          {isActive ? (
                            <button
                              onClick={() => handleOpenTransfer(loan)}
                              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                            >
                              Transfer Loan ⇄
                            </button>
                          ) : (
                            <span
                              title="Only ACTIVE loans are eligible for transfer"
                              className="text-xs text-slate-400 italic cursor-not-allowed"
                            >
                              Not Transferable
                            </span>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>

      {/* Transfer Loan Modal Dialog */}
      <TransferLoanModal
        isOpen={isModalOpen}
        loan={selectedLoan}
        users={users}
        onClose={() => {
          setIsModalOpen(false)
          setSelectedLoan(null)
        }}
        onSuccess={handleTransferSuccess}
      />

      {/* Audit Trail Modal */}
      {viewingAuditLoan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Transfer Audit Trail — Loan #{viewingAuditLoan.id}
                </h3>
                <p className="text-xs text-slate-500">{viewingAuditLoan.equipment.name}</p>
              </div>
              <button
                onClick={() => setViewingAuditLoan(null)}
                className="text-slate-400 hover:text-slate-600 text-lg p-1"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-3 max-h-96 overflow-y-auto">
              {viewingAuditLoan.transfers && viewingAuditLoan.transfers.length > 0 ? (
                viewingAuditLoan.transfers.map((t, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-slate-500">
                      <span className="font-semibold text-slate-700">Transfer Record #{t.id}</span>
                      <span>{formatDate(t.transferredAt)}</span>
                    </div>
                    <p className="text-slate-800">
                      From: <strong className="text-slate-900">{t.fromBorrower.name}</strong> ➔ To:{' '}
                      <strong className="text-indigo-700">{t.toBorrower.name}</strong>
                    </p>
                    <p className="text-slate-600 text-[11px]">
                      Authorized by: <strong>{t.transferredBy.name}</strong> (ADMIN)
                    </p>
                    {t.reason && (
                      <p className="text-slate-600 text-[11px] italic bg-white p-1.5 rounded border border-slate-200">
                        Reason: &quot;{t.reason}&quot;
                      </p>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500">No transfers recorded for this loan.</p>
              )}
            </div>
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setViewingAuditLoan(null)}
                className="px-4 py-1.5 text-xs font-semibold bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500 mt-auto">
        AV Room Management System • Active Loan Transfer Module
      </footer>
    </div>
  )
}

export default App
